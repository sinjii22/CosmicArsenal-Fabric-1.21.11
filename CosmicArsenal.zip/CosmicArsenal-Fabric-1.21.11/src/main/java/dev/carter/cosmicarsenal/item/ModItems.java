package dev.carter.cosmicarsenal.item;

import dev.carter.cosmicarsenal.CosmicArsenal;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public final class ModItems {
    private ModItems() {}

    private static final ResourceKey<Item> COSMIC_STAFF_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(CosmicArsenal.MOD_ID, "cosmic_staff")
    );

    public static final Item COSMIC_STAFF = Registry.register(
            BuiltInRegistries.ITEM,
            Identifier.fromNamespaceAndPath(CosmicArsenal.MOD_ID, "cosmic_staff"),
            new CosmicStaffItem(new Item.Properties()
                    .setId(COSMIC_STAFF_KEY)
                    .stacksTo(1)
                    .rarity(Rarity.EPIC)
                    .fireResistant())
    );

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> entries.accept(COSMIC_STAFF));
    }
}
