package dev.carter.cosmicarsenal.item;

import dev.carter.cosmicarsenal.effect.CosmicSequence;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.Mth;

public final class CosmicStaffItem extends Item {
    private static final int COOLDOWN_TICKS = 20 * 50;

    public CosmicStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }
        if (user.getCooldowns().isOnCooldown(this)) {
            return InteractionResult.FAIL;
        }

        BlockPos target = findGroundTarget(level, user);
        activate(serverLevel, user, target);
        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player user = context.getPlayer();
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }
        if (user != null && user.getCooldowns().isOnCooldown(this)) {
            return InteractionResult.FAIL;
        }

        BlockPos clicked = context.getClickedPos();
        BlockPos target = findSurface(level, clicked.getX(), clicked.getZ());
        activate(serverLevel, user, target);
        return InteractionResult.SUCCESS;
    }

    private void activate(ServerLevel level, Player user, BlockPos target) {
        CosmicSequence.start(level, target, user == null ? null : user.getUUID());
        if (user != null) {
            user.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            user.displayClientMessage(Component.literal("§b☄ Cosmic sequence initiated... §7Keep your distance!"), true);
        }
    }

    private BlockPos findGroundTarget(Level level, Player user) {
        Vec3 start = user.getEyePosition();
        Vec3 end = start.add(user.getLookAngle().scale(48.0));
        BlockHitResult hit = level.clip(new ClipContext(
                start,
                end,
                ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE,
                user
        ));

        double targetX = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos().getX() + 0.5 : end.x;
        double targetZ = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos().getZ() + 0.5 : end.z;
        return findSurface(level, Mth.floor(targetX), Mth.floor(targetZ));
    }

    private BlockPos findSurface(Level level, int x, int z) {
        int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        surfaceY = Math.max(level.getMinY() + 1, surfaceY);
        return new BlockPos(x, surfaceY, z);
    }
}
