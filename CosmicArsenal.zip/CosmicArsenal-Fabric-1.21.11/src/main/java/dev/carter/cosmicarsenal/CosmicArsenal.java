package dev.carter.cosmicarsenal;

import dev.carter.cosmicarsenal.effect.CosmicSequence;
import dev.carter.cosmicarsenal.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CosmicArsenal implements ModInitializer {
    public static final String MOD_ID = "cosmicarsenal";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ServerTickEvents.END_SERVER_TICK.register(server -> CosmicSequence.tick());
        LOGGER.info("Cosmic Arsenal loaded for Minecraft 1.21.11.");
    }
}
