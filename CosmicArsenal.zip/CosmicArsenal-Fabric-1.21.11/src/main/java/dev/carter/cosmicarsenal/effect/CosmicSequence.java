package dev.carter.cosmicarsenal.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Server-authoritative, particle-based approximation of the solar-system / supernova effect.
 * The crater is intentionally destructive; use a backup world when testing.
 */
public final class CosmicSequence {
    private static final List<CosmicSequence> ACTIVE = new ArrayList<>();

    private static final double[] ORBIT_RADII = {4.5, 7.5, 10.5, 13.5};
    private static final ParticleOptions[] PLANET_PARTICLES = {
            ParticleTypes.END_ROD,
            ParticleTypes.ELECTRIC_SPARK,
            ParticleTypes.SOUL_FIRE_FLAME,
            ParticleTypes.CRIT,
            ParticleTypes.ENCHANT,
            ParticleTypes.PORTAL
    };

    private final ServerLevel level;
    private final BlockPos center;
    private final UUID caster;
    private int age;

    private CosmicSequence(ServerLevel level, BlockPos center, UUID caster) {
        this.level = level;
        this.center = center.immutable();
        this.caster = caster;
    }

    public static void start(ServerLevel level, BlockPos center, UUID caster) {
        ACTIVE.add(new CosmicSequence(level, center, caster));
        level.playSound(null, center, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 2.0F, 0.65F);
    }

    public static void tick() {
        Iterator<CosmicSequence> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().tickSequence()) {
                iterator.remove();
            }
        }
    }

    private boolean tickSequence() {
        age++;
        double cx = center.getX() + 0.5;
        double cz = center.getZ() + 0.5;
        double groundY = center.getY() + 1.0;
        double skyY = groundY + 26.0;

        if (age <= 120) {
            if (age % 10 == 0) {
                drawOrbits(cx, skyY, cz);
            }
            drawPlanets(cx, skyY, cz);
            if (age % 3 == 0) {
                drawSunCore(cx, skyY, cz, 1.15);
            }
        } else if (age <= 180) {
            double t = (age - 120) / 60.0;
            double radius = 1.5 + t * 14.5;
            double sunY = skyY - t * 4.0;
            if (age % 4 == 0) {
                drawSphere(cx, sunY, cz, radius);
            }
            drawSunCore(cx, sunY, cz, Math.max(1.5, radius * 0.35));
        } else if (age <= 220) {
            double t = (age - 180) / 40.0;
            double radius = 16.0;
            double sunY = skyY - t * (skyY - (groundY + 3.0));
            if (age % 4 == 0) {
                drawSphere(cx, sunY, cz, radius);
            }
            if (age % 8 == 0) {
                drawGroundRing(cx, cz, radius * (0.45 + t * 0.55), groundY + 0.15);
            }
        }

        if (age == 221) {
            detonate(cx, groundY, cz);
        }
        return age > 255;
    }

    private void drawOrbits(double cx, double y, double cz) {
        for (int ring = 0; ring < ORBIT_RADII.length; ring++) {
            double radius = ORBIT_RADII[ring];
            ParticleOptions particle = ring % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ELECTRIC_SPARK;
            for (int point = 0; point < 20; point++) {
                double angle = Math.PI * 2.0 * point / 20.0;
                double x = cx + Math.cos(angle) * radius;
                double z = cz + Math.sin(angle) * radius;
                level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    private void drawPlanets(double cx, double y, double cz) {
        for (int i = 0; i < ORBIT_RADII.length + 2; i++) {
            double radius = i < ORBIT_RADII.length ? ORBIT_RADII[i] : 3.0 + i * 1.8;
            double speed = 0.018 + i * 0.003;
            double angle = age * speed + i * 1.12;
            double x = cx + Math.cos(angle) * radius;
            double z = cz + Math.sin(angle) * radius;
            double py = y + Math.sin(angle * 1.7) * 0.18;
            ParticleOptions planet = PLANET_PARTICLES[i % PLANET_PARTICLES.length];
            level.sendParticles(planet, x, py, z, 2, 0.06, 0.06, 0.06, 0.01);
            if (age % 3 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, x, py, z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    private void drawSunCore(double x, double y, double z, double spread) {
        level.sendParticles(ParticleTypes.FLAME, x, y, z, 5, spread * 0.25, spread * 0.2, spread * 0.25, 0.015);
        level.sendParticles(ParticleTypes.LAVA, x, y, z, 2, spread * 0.15, spread * 0.15, spread * 0.15, 0.0);
        level.sendParticles(ParticleTypes.END_ROD, x, y, z, 2, spread * 0.08, spread * 0.08, spread * 0.08, 0.01);
    }

    private void drawSphere(double cx, double cy, double cz, double radius) {
        for (int latitude = -1; latitude <= 1; latitude++) {
            double phi = latitude * Math.PI / 4.0;
            double ringRadius = radius * Math.cos(phi);
            double y = cy + radius * Math.sin(phi);
            for (int point = 0; point < 16; point++) {
                double angle = Math.PI * 2.0 * point / 16.0;
                double x = cx + Math.cos(angle) * ringRadius;
                double z = cz + Math.sin(angle) * ringRadius;
                ParticleOptions particle = ((point + latitude) & 1) == 0
                        ? ParticleTypes.FLAME
                        : ParticleTypes.SOUL_FIRE_FLAME;
                level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.005);
            }
        }
        level.sendParticles(ParticleTypes.LAVA, cx, cy, cz, 10, radius * 0.1, radius * 0.1, radius * 0.1, 0.02);
    }

    private void drawGroundRing(double cx, double cz, double radius, double y) {
        for (int point = 0; point < 28; point++) {
            double angle = Math.PI * 2.0 * point / 28.0;
            double x = cx + Math.cos(angle) * radius;
            double z = cz + Math.sin(angle) * radius;
            ParticleOptions particle = point % 3 == 0 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME;
            level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void detonate(double cx, double groundY, double cz) {
        BlockPos soundPos = BlockPos.containing(cx, groundY, cz);
        level.playSound(null, soundPos, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 5.0F, 0.55F);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, cx, groundY + 1.0, cz, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.SONIC_BOOM, cx, groundY + 2.0, cz, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.FLAME, cx, groundY + 1.0, cz, 160, 12.0, 2.0, 12.0, 0.14);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, cx, groundY + 2.0, cz, 90, 9.0, 4.0, 9.0, 0.08);
        level.sendParticles(ParticleTypes.CLOUD, cx, groundY + 1.0, cz, 70, 10.0, 1.0, 10.0, 0.12);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx, groundY + 2.0, cz, 100, 11.0, 2.5, 11.0, 0.16);

        drawGroundRing(cx, cz, 6.0, groundY + 0.2);
        drawGroundRing(cx, cz, 10.0, groundY + 0.2);
        drawGroundRing(cx, cz, 14.0, groundY + 0.2);
        carveCrater();
        damageNearbyEntities(cx, groundY, cz);
    }

    private void carveCrater() {
        final int radius = 14;
        final int maxDepth = 7;
        int centerX = center.getX();
        int centerZ = center.getZ();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double distance = Math.sqrt(dx * dx + dz * dz);
                if (distance > radius) continue;

                int x = centerX + dx;
                int z = centerZ + dz;
                int topY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                double bowl = Math.sqrt(Math.max(0.0, 1.0 - distance / radius));
                int depth = (int) Math.ceil(maxDepth * bowl);
                int floorY = Math.max(level.getMinY() + 1, topY - depth);

                for (int y = floorY; y < topY; y++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || state.hasBlockEntity() || isProtectedBlock(state)) continue;
                    if (state.getDestroySpeed(level, pos) >= 0.0F) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    }
                }
            }
        }
    }

    private boolean isProtectedBlock(BlockState state) {
        return state.is(Blocks.BEDROCK)
                || state.is(Blocks.BARRIER)
                || state.is(Blocks.OBSIDIAN)
                || state.is(Blocks.CRYING_OBSIDIAN)
                || state.is(Blocks.REINFORCED_DEEPSLATE)
                || state.is(Blocks.END_PORTAL_FRAME)
                || state.is(Blocks.COMMAND_BLOCK)
                || state.is(Blocks.CHAIN_COMMAND_BLOCK)
                || state.is(Blocks.REPEATING_COMMAND_BLOCK)
                || state.is(Blocks.STRUCTURE_BLOCK)
                || state.is(Blocks.STRUCTURE_VOID)
                || state.is(Blocks.JIGSAW);
    }

    private void damageNearbyEntities(double cx, double groundY, double cz) {
        double radius = 18.0;
        AABB box = new AABB(cx - radius, groundY - 8.0, cz - radius,
                cx + radius, groundY + 12.0, cz + radius);
        Vec3 origin = new Vec3(cx, groundY, cz);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (caster != null && caster.equals(entity.getUUID())) continue;
            double distance = entity.position().distanceTo(origin);
            if (distance > radius) continue;
            float damage = (float) Math.max(8.0, 65.0 * (1.0 - distance / radius));
            DamageSource source = level.damageSources().magic();
            entity.hurtServer(level, source, damage);
            Vec3 direction = entity.position().subtract(origin);
            if (direction.lengthSqr() > 0.001) {
                direction = direction.normalize();
                entity.setDeltaMovement(entity.getDeltaMovement().add(direction.x * 1.25, 1.0, direction.z * 1.25));
            }
        }
    }
}
