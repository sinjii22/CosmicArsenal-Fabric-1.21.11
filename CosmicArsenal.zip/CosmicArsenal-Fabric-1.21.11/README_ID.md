# Cosmic Arsenal — Fabric 1.21.11

Mod Minecraft Java yang meniru efek di video: sistem orbit kosmik, matahari yang membesar, efek supernova, gelombang ledakan, kerusakan area, dan kawah.

## Target

- Minecraft Java Edition **1.21.11**
- Fabric Loader **0.18.4 atau lebih baru**
- Fabric API **0.141.6+1.21.11 atau lebih baru untuk Minecraft 1.21.11**
- Java **21**
- Fabric Loom **1.14.10**

## Cara memakai setelah mod berhasil dibuild

1. Jalankan Minecraft Java 1.21.11 dengan Fabric Loader.
2. Pasang Fabric API untuk versi 1.21.11 di folder `mods`.
3. Salin `cosmic-arsenal-1.0.0.jar` dari folder `build/libs/` ke folder `mods`.
4. Masuk ke dunia, lalu jalankan:

   ```mcfunction
   /give @p cosmicarsenal:cosmic_staff
   ```

5. Pegang **Cosmic Staff / Tongkat Kosmik**, lalu klik kanan. Arahkan ke tanah atau klik langsung sebuah blok.
6. Animasi berlangsung sekitar 12 detik. Cooldown sekitar 50 detik.

## Peringatan penting

**Efek akhirnya menghancurkan blok dan membuat kawah sekitar 28 blok lebar serta dapat melukai entitas di sekitarnya.** Uji di dunia salinan/creative terlebih dahulu. Mod ini melindungi bedrock, barrier, obsidian, reinforced deepslate, command block, structure block, dan blok yang memiliki block entity, tetapi tetap dapat menghancurkan medan normal.

## Build

Perlu Java 21 dan koneksi internet pada komputer yang membuild, karena Gradle harus mengunduh Minecraft, Fabric Loader, Fabric API, dan dependensi Loom.

Di folder proyek, jalankan:

```bash
./gradlew build
```

Di Windows, gunakan `gradlew.bat build`. Script akan mengunduh Gradle 9.2.1 saat pertama kali dijalankan. Alternatifnya, buka folder ini sebagai proyek Gradle di IntelliJ IDEA dan jalankan task `build`. JAR hasil build akan berada di `build/libs/`.

## Batasan versi awal

Efek visual dibuat menggunakan partikel bawaan Minecraft supaya tetap kompatibel dengan server Fabric dan tidak memerlukan shader khusus. Karena itu, bentuk planet/orbit berupa jejak partikel, bukan model planet 3D bertekstur seperti efek add-on Bedrock di video. Kode sumber belum dikompilasi atau diuji di klien Minecraft dalam lingkungan ini; build pertama perlu dijalankan dengan dependensi Gradle tersedia.
